package co.edu.sena.tu_unidad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TuUnidadApplicationTests {

	@Test
	void contextLoads() {
	}

}
