package co.edu.sena.adso.ejercicios;

public class Ejercicio2 {

    public static void main(String[] args) {
        System.out.println("Hola mundo");
    }

}
